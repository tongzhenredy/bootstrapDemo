
Bootstrap from twitter 的示例代码

每一个html页面包含最多一种类型的示例
---
既然官方已经有了那么详细的文档还要重新写一遍呢？
一是为了熟悉语法，而是为了明确每个具体的示例到底需要哪些css文件和js文件。
方便以后直接过来copy~
---

页面的编写依据
http://wrongwaycn.github.com/bootstrap/docs/

也算是官方文档的阅读笔记


----------

以下是示例文件夹


WebRoot、
	kuangjia
	jicucss
	zujian
	jqplugins
		
	less [参考官方网站：http://www.lesscss.net/]
	
	
	


